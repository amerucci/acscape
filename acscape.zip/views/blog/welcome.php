<h1>Homepage</h1>

<p>Ouais le problème c'est qu'on a passé quatre semaines à construire un barrage, ça fait un peu mal au cul de le
    détruire. Mais arrêtez avec votre chevalier gaulois! Je vous dis que c’est des conneries! Ca vous emmerde ce que
    j’raconte? P’tite pucelle!

    Non mais maintenant il faut se tirer dans l'autre sens. Mais parce qu’on a des frais! Vous pouvez pas vous rentrer
    ça dans le crâne? Mais ça va! Pourquoi vous m’agressez? Mais ils ont pas le droit de décider de la retraite
    eux-mêmes! On l’a dit et redit ça! On pourrait balancer de la caillasse vers là-bas, comme ça ils se disent qu'on y
    est et on part dans l'autre sens.

    Il s’est fait chier dessus par un bouc! Ben c’est bien ce que j’ai dit! Provençal le Gaulois… le Galois… Ouais je
    vois ce que vous voulez dire… Et alors c'est pas permis?

    Y a pas d’herbe dans la salle du trône. C’est du patrimoine ça? Ouais, y a pas à dire, quand y a du dessert le repas
    est tout de suite plus chaleureux! S’il vous plait! Faites pas votre mijoré! Moi je me fais traiter de gonzesse j’en
    fais pas tout un cake! S'il y a un autre qui groupe qui arrive par là on est marron des deux côtés. Qu’est ce que
    j’ai dit? Une connerie?

    C’est la salle du trône. Il ferait beau voir que je puisse pas y rentrer! Oui… Ben vous… Occupez vous d’les faire ça
    s’ra déjà pas mal! Mais ça va! Pourquoi vous m’agressez? Mais attendez… Y a une table et des sièges et j’devrais
    m’farcir toutes les notes à ratifier debout? N’empêche que tout le monde parle de moi! C’est quand même un signe!
    Mais vous êtes complètement con?</p>


<img src="https://imgs.search.brave.com/CtNC7u19Jj91KXj2Nm8Ygzw3DRytC_VDi6yBzLRHByI/rs:fit:1200:628:1/g:ce/aHR0cHM6Ly9jZG4u/ZXZlbnRhc3RpYy5m/ci9tZWRpYS90aHVt/Yi9vcEdyYXBoRmJU/aHVtYi9odHRwcy0t/LWNkbi5ldmVudGFz/dGljLmZyL3VwbG9h/ZC9wcmVzdGFfZmls/ZXMvMTU3Mjg3Mzk2/MDUuMTU3Mjg3Mzky/MDI5NS42NjY3Lmpw/Zw"
    alt="" width=400>

<p>Vous savez c’est quand de même pas grave de pas savoir faire des tartes! Y a quand même pas cinquante trucs à retenir
    bon sang! Ben quoi? C’est pas si grave que ça! Non Provençal c’est mon nom.

    Encore une chance qu’on se soit pas fait construire un buffet à vaisselle. J’ai envie d’faire des tartes, voilà!
    Vous n’allez pas m’obliger à m’justifier! Très exactement c’est «Provençal le Gaulois». On pourrait foutre le feu à
    la forêt pour les obliger à sortir.

    Merde j'ai plus de pierres qu'est-ce qu'on fait? Ah ah Sire! Je vous attends! À moins que vous préfériez qu’on dise
    partout que le roi est une petite pédale qui pisse dans son froc à l’idée d’se battre! Ouais… Ouais je me suis
    gouré… Déjà à la corne, ils regardent même pas vers ici! Vous pouvez bien agiter tout les drapeaux que vous voudrez!

    Allez en garde ma mignonne! Mais parce qu’on a des frais! Vous pouvez pas vous rentrer ça dans le crâne? Alors là,
    personne sait qui est tombé et tout le monde s’en fout! Ah, ben tourné vers là-bas c'est sûr, moi non plus je vois
    rien.

    Bon alors en garde, fils d’unijambiste. N’empêche que j’suis une légende! P’tite pucelle! Non Provençal c’est mon
    nom.</p>

<p>Ouais le problème c'est qu'on a passé quatre semaines à construire un barrage, ça fait un peu mal au cul de le
    détruire. Mais arrêtez avec votre chevalier gaulois! Je vous dis que c’est des conneries! Ca vous emmerde ce que
    j’raconte? P’tite pucelle!

    Non mais maintenant il faut se tirer dans l'autre sens. Mais parce qu’on a des frais! Vous pouvez pas vous rentrer
    ça dans le crâne? Mais ça va! Pourquoi vous m’agressez? Mais ils ont pas le droit de décider de la retraite
    eux-mêmes! On l’a dit et redit ça! On pourrait balancer de la caillasse vers là-bas, comme ça ils se disent qu'on y
    est et on part dans l'autre sens.

    Il s’est fait chier dessus par un bouc! Ben c’est bien ce que j’ai dit! Provençal le Gaulois… le Galois… Ouais je
    vois ce que vous voulez dire… Et alors c'est pas permis?

    Y a pas d’herbe dans la salle du trône. C’est du patrimoine ça? Ouais, y a pas à dire, quand y a du dessert le repas
    est tout de suite plus chaleureux! S’il vous plait! Faites pas votre mijoré! Moi je me fais traiter de gonzesse j’en
    fais pas tout un cake! S'il y a un autre qui groupe qui arrive par là on est marron des deux côtés. Qu’est ce que
    j’ai dit? Une connerie?

    C’est la salle du trône. Il ferait beau voir que je puisse pas y rentrer! Oui… Ben vous… Occupez vous d’les faire ça
    s’ra déjà pas mal! Mais ça va! Pourquoi vous m’agressez? Mais attendez… Y a une table et des sièges et j’devrais
    m’farcir toutes les notes à ratifier debout? N’empêche que tout le monde parle de moi! C’est quand même un signe!
    Mais vous êtes complètement con?</p>